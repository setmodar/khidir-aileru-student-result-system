# make_sample_data.py
# run this once to fill students.json with some test students
# Author: Khidir Segun Aileru (24/sci01/019)

import storage
from student import Student

people = [
    ("24/sci01/019", "Khidir Segun Aileru", "M", "12-03-2005", [78, 85, 72, 69, 80]),
    ("24/sci01/020", "Kene Okafor",         "M", "04-07-2005", [65, 58, 70, 62, 55]),
    ("24/sci01/021", "Antho Williams",      "M", "19-11-2004", [48, 52, 45, 60, 50]),
    ("24/sci01/022", "Azeez Bello",         "M", "23-01-2005", [88, 74, 91, 79, 83]),
    ("24/sci01/023", "Tolu Adeyemi",        "F", "30-05-2005", [40, 35, 52, 44, 38]),
    ("24/sci01/024", "Chioma Eze",          "F", "09-09-2005", [92, 88, 85, 90, 94]),
]

subjects = ["Mathematics", "English", "Physics", "Chemistry", "Biology"]
students = []
for p in people:
    s = Student(p[0], p[1], "SS3", p[2], p[3])
    for i in range(5):
        s.add_score(subjects[i], p[4][i])
    students.append(s)

storage.save_students(students)
print("Sample data created.")
