# student.py
# Student class and ID validation
# Author: Khidir Segun Aileru (24/sci01/019)

import re
from datetime import datetime

# the id must look like 24/sci01/019
ID_PATTERN = r"^\d{2}/[a-zA-Z]{3}\d{2}/\d{3}$"


def valid_id(student_id):
    # returns True if the id matches the pattern
    if re.match(ID_PATTERN, student_id):
        return True
    return False


class Student:
    def __init__(self, student_id, name, student_class, gender, dob, scores=None, date_entered=None):
        self.student_id = student_id
        self.name = name
        self.student_class = student_class
        self.gender = gender
        self.dob = dob
        # scores is a dictionary e.g. {"Maths": 70, "English": 65}
        if scores is None:
            self.scores = {}
        else:
            self.scores = scores
        self.date_entered = date_entered

    def add_score(self, subject, score):
        self.scores[subject] = score
        # save the date the result was entered
        self.date_entered = datetime.now().strftime("%Y-%m-%d %H:%M")

    def to_dict(self):
        # used when saving to json
        return {
            "student_id": self.student_id,
            "name": self.name,
            "student_class": self.student_class,
            "gender": self.gender,
            "dob": self.dob,
            "scores": self.scores,
            "date_entered": self.date_entered,
        }

    @staticmethod
    def from_dict(d):
        # used when loading from json
        return Student(d["student_id"], d["name"], d["student_class"],
                       d["gender"], d["dob"], d["scores"], d["date_entered"])
