# storage.py
# load and save the students to a json file
# Author: Khidir Segun Aileru (24/sci01/019)

import json
import os
from student import Student

DATA_FOLDER = "data"
DATA_FILE = os.path.join(DATA_FOLDER, "students.json")


def load_students():
    students = []
    # if the file is not there yet we just start with an empty list
    if not os.path.exists(DATA_FILE):
        print("No data file found, starting fresh.")
        return students

    try:
        with open(DATA_FILE, "r") as f:
            data = json.load(f)
    except json.JSONDecodeError:
        print("Data file is damaged, starting fresh.")
        return students
    else:
        for item in data:
            students.append(Student.from_dict(item))
    finally:
        pass  # nothing to clean up, file closes by itself

    return students


def save_students(students):
    if not os.path.exists(DATA_FOLDER):
        os.makedirs(DATA_FOLDER)

    data = []
    for s in students:
        data.append(s.to_dict())

    try:
        with open(DATA_FILE, "w") as f:
            json.dump(data, f, indent=4)
    except OSError as e:
        print("Could not save data:", e)
