# Student Result Management System

**Name:** Khidir Segun Aileru
**Matric No:** 24/sci01/019
**Course:** Introduction to Python Programming (New Horizon)

## About
A menu-driven Python program that helps a school register students, record
scores for 5 subjects, calculate total/average/grade, and print report cards
and class reports. Data is saved in a JSON file so it is not lost when the
program closes.

## How to run
1. Install Python 3 (no extra libraries needed).
2. Open a terminal in this folder.
3. (Optional) Add sample students: `python make_sample_data.py`
4. Start the program: `python main.py`

## Files
- `main.py` - menu and main program
- `student.py` - Student class and ID check (regex)
- `results.py` - total, average, grade, statistics, sorting
- `storage.py` - load and save JSON
- `reports.py` - report card and text report
- `data/students.json` - saved data
- `reports/` - saved text reports

## Grading
| Average | Grade |
|---------|-------|
| 70+ | A |
| 60-69 | B |
| 50-59 | C |
| 45-49 | D |
| below 45 | F |

## Python concepts used
Variables and type conversion, if/elif/else, for and while loops, lists,
dictionaries, functions, sorting (`sorted` with key), try/except/else/finally,
file handling with JSON, multiple modules, a Student class (OOP),
`datetime` for the date a result was entered, `os`, `json`, `re` (regex).
