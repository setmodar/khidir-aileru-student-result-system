# results.py
# calculations for total, average and grade
# Author: Khidir Segun Aileru (24/sci01/019)


def get_total(student):
    total = 0
    for subject in student.scores:
        total = total + student.scores[subject]
    return total


def get_average(student):
    if len(student.scores) == 0:
        return 0
    return get_total(student) / len(student.scores)


def get_grade(average):
    if average >= 70:
        return "A"
    elif average >= 60:
        return "B"
    elif average >= 50:
        return "C"
    elif average >= 45:
        return "D"
    else:
        return "F"


def class_stats(students):
    # returns highest score, lowest score and class average
    all_scores = []
    averages = []
    for s in students:
        for subject in s.scores:
            all_scores.append(s.scores[subject])
        averages.append(get_average(s))

    if len(all_scores) == 0:
        return None

    stats = {
        "highest": max(all_scores),
        "lowest": min(all_scores),
        "class_average": sum(averages) / len(averages),
    }
    return stats


def sort_by_average(students):
    # highest to lowest
    return sorted(students, key=get_average, reverse=True)


def sort_by_name(students):
    return sorted(students, key=lambda s: s.name.lower())
