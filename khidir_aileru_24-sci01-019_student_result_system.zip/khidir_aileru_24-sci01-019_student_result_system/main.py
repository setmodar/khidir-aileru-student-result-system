# main.py
# Student Result Management System - New Horizon
# Name   : Khidir Segun Aileru
# Matric : 24/sci01/019
# Course : Introduction to Python Programming

import storage
import results
import reports
from student import Student, valid_id

# the subjects every student must have (at least 5)
SUBJECTS = ["Mathematics", "English", "Physics", "Chemistry", "Biology"]

students = storage.load_students()


def find_student(student_id):
    for s in students:
        if s.student_id.lower() == student_id.lower():
            return s
    return None


def get_score(subject):
    # keep asking until the person types a number from 0 to 100
    while True:
        try:
            score = float(input(f"  {subject} score (0-100): "))
        except ValueError:
            print("  Please type a number.")
            continue
        if score < 0 or score > 100:
            print("  Score must be between 0 and 100.")
        else:
            return score


def add_student():
    student_id = input("Student ID (e.g. 24/sci01/019): ").strip()
    if not valid_id(student_id):
        print("Wrong ID format!")
        return
    if find_student(student_id) is not None:
        print("That ID is already registered.")
        return

    name = input("Full name: ").strip()
    student_class = input("Class/Form: ").strip()
    gender = input("Gender (M/F): ").strip().upper()
    dob = input("Date of birth (DD-MM-YYYY): ").strip()

    if name == "" or student_class == "":
        print("Name and class cannot be empty.")
        return

    students.append(Student(student_id, name, student_class, gender, dob))
    storage.save_students(students)
    print("Student added.")


def view_students():
    if len(students) == 0:
        print("No students yet.")
        return
    print(f"\n{'ID':<14}{'Name':<22}{'Class':<8}{'Gender'}")
    for s in students:
        print(f"{s.student_id:<14}{s.name:<22}{s.student_class:<8}{s.gender}")


def search_student():
    word = input("Enter ID or name to search: ").strip().lower()
    found = False
    for s in students:
        if word in s.student_id.lower() or word in s.name.lower():
            print(s.student_id, "-", s.name, "-", s.student_class)
            found = True
    if not found:
        print("No student found.")


def update_student():
    s = find_student(input("Enter student ID: ").strip())
    if s is None:
        print("Student not found.")
        return
    print("Leave blank to keep the old value.")
    name = input(f"Name [{s.name}]: ").strip()
    cls = input(f"Class [{s.student_class}]: ").strip()
    gender = input(f"Gender [{s.gender}]: ").strip().upper()
    dob = input(f"DOB [{s.dob}]: ").strip()

    if name != "":
        s.name = name
    if cls != "":
        s.student_class = cls
    if gender != "":
        s.gender = gender
    if dob != "":
        s.dob = dob
    storage.save_students(students)
    print("Student updated.")


def delete_student():
    s = find_student(input("Enter student ID: ").strip())
    if s is None:
        print("Student not found.")
        return
    sure = input(f"Delete {s.name}? (y/n): ").lower()
    if sure == "y":
        students.remove(s)
        storage.save_students(students)
        print("Deleted.")


def record_scores():
    # works for new scores and also for updating old ones
    s = find_student(input("Enter student ID: ").strip())
    if s is None:
        print("Student not found.")
        return
    print("Enter scores for", s.name)
    for subject in SUBJECTS:
        s.add_score(subject, get_score(subject))
    storage.save_students(students)
    print("Scores saved.")


def update_one_score():
    s = find_student(input("Enter student ID: ").strip())
    if s is None:
        print("Student not found.")
        return
    subject = input("Subject to update: ").strip().title()
    if subject not in s.scores:
        print("That subject has no score yet.")
        return
    s.add_score(subject, get_score(subject))
    storage.save_students(students)
    print("Score updated.")


def show_report_card():
    s = find_student(input("Enter student ID: ").strip())
    if s is None:
        print("Student not found.")
    elif len(s.scores) < 5:
        print("This student does not have 5 subject scores yet.")
    else:
        print(reports.report_card(s))


def show_all_results():
    print(reports.class_report(students))


def sorted_list():
    choice = input("Sort by (1) average or (2) name: ").strip()
    if choice == "1":
        lst = results.sort_by_average(students)
    elif choice == "2":
        lst = results.sort_by_name(students)
    else:
        print("Invalid choice.")
        return
    print(reports.class_report(lst))


def show_stats():
    stats = results.class_stats(students)
    if stats is None:
        print("No scores recorded yet.")
        return
    print("Highest score :", stats["highest"])
    print("Lowest score  :", stats["lowest"])
    print("Class average :", round(stats["class_average"], 2))


def save_text_report():
    text = reports.class_report(results.sort_by_average(students))
    reports.save_report(text)


def menu():
    print("\n===== STUDENT RESULT SYSTEM =====")
    print("1.  Add student")
    print("2.  View all students")
    print("3.  Search student")
    print("4.  Update student")
    print("5.  Delete student")
    print("6.  Record scores")
    print("7.  Update a score")
    print("8.  Student report card")
    print("9.  All results")
    print("10. Sort students")
    print("11. Class statistics")
    print("12. Save report to file")
    print("0.  Exit")


def main():
    actions = {
        "1": add_student, "2": view_students, "3": search_student,
        "4": update_student, "5": delete_student, "6": record_scores,
        "7": update_one_score, "8": show_report_card, "9": show_all_results,
        "10": sorted_list, "11": show_stats, "12": save_text_report,
    }

    while True:
        menu()
        choice = input("Choose an option: ").strip()
        if choice == "0":
            storage.save_students(students)
            print("Goodbye!")
            break
        elif choice in actions:
            actions[choice]()
        else:
            print("Invalid option, try again.")


if __name__ == "__main__":
    main()
