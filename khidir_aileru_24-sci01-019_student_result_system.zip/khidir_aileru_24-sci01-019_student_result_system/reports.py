# reports.py
# report card and full class report
# Author: Khidir Segun Aileru (24/sci01/019)

import os
from datetime import datetime
import results


def report_card(student):
    # returns the report card as text
    line = "=" * 40 + "\n"
    text = line
    text += "         STUDENT REPORT CARD\n"
    text += line
    text += "ID     : " + student.student_id + "\n"
    text += "Name   : " + student.name + "\n"
    text += "Class  : " + student.student_class + "\n"
    text += "Gender : " + student.gender + "\n"
    text += "DOB    : " + student.dob + "\n"
    text += "-" * 40 + "\n"

    for subject, score in student.scores.items():
        text += f"{subject:<20} {score:>5}\n"

    avg = results.get_average(student)
    text += "-" * 40 + "\n"
    text += f"Total   : {results.get_total(student)}\n"
    text += f"Average : {avg:.2f}\n"
    text += f"Grade   : {results.get_grade(avg)}\n"
    if student.date_entered:
        text += f"Result entered on: {student.date_entered}\n"
    text += line
    return text


def class_report(students):
    # list of all students with total, average and grade
    text = "NEW HORIZON - CLASS RESULT REPORT\n"
    text += "Generated: " + datetime.now().strftime("%Y-%m-%d %H:%M") + "\n\n"
    text += f"{'ID':<14}{'Name':<22}{'Total':>7}{'Average':>9}{'Grade':>7}\n"
    text += "-" * 59 + "\n"

    for s in students:
        avg = results.get_average(s)
        text += f"{s.student_id:<14}{s.name:<22}{results.get_total(s):>7}{avg:>9.2f}{results.get_grade(avg):>7}\n"

    stats = results.class_stats(students)
    if stats:
        text += "\nHighest score : " + str(stats["highest"])
        text += "\nLowest score  : " + str(stats["lowest"])
        text += "\nClass average : " + str(round(stats["class_average"], 2)) + "\n"
    return text


def save_report(text, filename="class_report.txt"):
    if not os.path.exists("reports"):
        os.makedirs("reports")
    path = os.path.join("reports", filename)
    try:
        with open(path, "w") as f:
            f.write(text)
        print("Report saved to", path)
    except OSError as e:
        print("Could not save report:", e)
